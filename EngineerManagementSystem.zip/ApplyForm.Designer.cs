﻿
namespace ManagerClient
{
    partial class ApplyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.uiDataGridView_RegInf = new Sunny.UI.UIDataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerPassword = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerSex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerBirth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerHomeAddr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerEdu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerAddr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerTel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.uiDataGridView_RegInf)).BeginInit();
            this.SuspendLayout();
            // 
            // uiDataGridView_RegInf
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.uiDataGridView_RegInf.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.uiDataGridView_RegInf.BackgroundColor = System.Drawing.Color.White;
            this.uiDataGridView_RegInf.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.uiDataGridView_RegInf.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.uiDataGridView_RegInf.ColumnHeadersHeight = 32;
            this.uiDataGridView_RegInf.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.uiDataGridView_RegInf.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.workerName,
            this.workerPassword,
            this.workerSex,
            this.workerBirth,
            this.workerHomeAddr,
            this.workerEdu,
            this.workerAddr,
            this.workerTel});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.uiDataGridView_RegInf.DefaultCellStyle = dataGridViewCellStyle3;
            this.uiDataGridView_RegInf.EnableHeadersVisualStyles = false;
            this.uiDataGridView_RegInf.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.uiDataGridView_RegInf.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.uiDataGridView_RegInf.Location = new System.Drawing.Point(31, 24);
            this.uiDataGridView_RegInf.Name = "uiDataGridView_RegInf";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.uiDataGridView_RegInf.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            this.uiDataGridView_RegInf.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.uiDataGridView_RegInf.RowTemplate.Height = 29;
            this.uiDataGridView_RegInf.SelectedIndex = -1;
            this.uiDataGridView_RegInf.ShowGridLine = true;
            this.uiDataGridView_RegInf.Size = new System.Drawing.Size(754, 415);
            this.uiDataGridView_RegInf.TabIndex = 0;
            this.uiDataGridView_RegInf.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.uiDataGridView_RegInf_CellContentDoubleClick);
            // 
            // id
            // 
            this.id.DataPropertyName = "id";
            this.id.HeaderText = "id";
            this.id.Name = "id";
            this.id.ReadOnly = true;
            // 
            // workerName
            // 
            this.workerName.DataPropertyName = "workerRegName";
            this.workerName.HeaderText = "姓名";
            this.workerName.Name = "workerName";
            this.workerName.ReadOnly = true;
            // 
            // workerPassword
            // 
            this.workerPassword.DataPropertyName = "workerRegPassword";
            this.workerPassword.HeaderText = "密码";
            this.workerPassword.Name = "workerPassword";
            this.workerPassword.ReadOnly = true;
            // 
            // workerSex
            // 
            this.workerSex.DataPropertyName = "workerRegSex";
            this.workerSex.HeaderText = "性别";
            this.workerSex.Name = "workerSex";
            this.workerSex.ReadOnly = true;
            // 
            // workerBirth
            // 
            this.workerBirth.DataPropertyName = "workerRegBirth";
            this.workerBirth.HeaderText = "生日";
            this.workerBirth.Name = "workerBirth";
            this.workerBirth.ReadOnly = true;
            // 
            // workerHomeAddr
            // 
            this.workerHomeAddr.DataPropertyName = "workerRegHomeAddr";
            this.workerHomeAddr.HeaderText = "籍贯";
            this.workerHomeAddr.Name = "workerHomeAddr";
            this.workerHomeAddr.ReadOnly = true;
            // 
            // workerEdu
            // 
            this.workerEdu.DataPropertyName = "workerRegEdu";
            this.workerEdu.HeaderText = "学历";
            this.workerEdu.Name = "workerEdu";
            this.workerEdu.ReadOnly = true;
            // 
            // workerAddr
            // 
            this.workerAddr.DataPropertyName = "workerRegAddr";
            this.workerAddr.HeaderText = "住址";
            this.workerAddr.Name = "workerAddr";
            this.workerAddr.ReadOnly = true;
            // 
            // workerTel
            // 
            this.workerTel.DataPropertyName = "workerRegTel";
            this.workerTel.HeaderText = "电话";
            this.workerTel.Name = "workerTel";
            this.workerTel.ReadOnly = true;
            // 
            // ApplyForm
            // 
            this.AllowShowTitle = false;
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(816, 465);
            this.Controls.Add(this.uiDataGridView_RegInf);
            this.Name = "ApplyForm";
            this.Padding = new System.Windows.Forms.Padding(0);
            this.ShowTitle = false;
            this.Text = "ApplyForm";
            this.Load += new System.EventHandler(this.ApplyForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.uiDataGridView_RegInf)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UIDataGridView uiDataGridView_RegInf;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerPassword;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerSex;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerBirth;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerHomeAddr;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerEdu;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerAddr;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerTel;
    }
}