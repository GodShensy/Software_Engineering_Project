﻿namespace ManagerClient
{
    class MinData
    {
        private string workerNumber;
        public string WorkerNumber { get => workerNumber; set => workerNumber = value; }
    }
}