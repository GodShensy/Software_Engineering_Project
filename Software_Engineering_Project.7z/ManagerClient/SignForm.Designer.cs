﻿
namespace ManagerClient
{
    partial class SignForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView_sign_data = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.signType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.signData = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.isChecked = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_sign_data)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_sign_data
            // 
            this.dataGridView_sign_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_sign_data.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.workerID,
            this.signType,
            this.signData,
            this.isChecked});
            this.dataGridView_sign_data.Location = new System.Drawing.Point(26, 25);
            this.dataGridView_sign_data.Name = "dataGridView_sign_data";
            this.dataGridView_sign_data.RowTemplate.Height = 25;
            this.dataGridView_sign_data.Size = new System.Drawing.Size(547, 394);
            this.dataGridView_sign_data.TabIndex = 0;
            this.dataGridView_sign_data.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_sign_data_CellContentClick);
            this.dataGridView_sign_data.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_sign_data_CellEndEdit);
            // 
            // id
            // 
            this.id.DataPropertyName = "id";
            this.id.HeaderText = "id";
            this.id.Name = "id";
            this.id.ReadOnly = true;
            // 
            // workerID
            // 
            this.workerID.DataPropertyName = "workerId";
            this.workerID.HeaderText = "编号";
            this.workerID.Name = "workerID";
            this.workerID.ReadOnly = true;
            this.workerID.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // signType
            // 
            this.signType.DataPropertyName = "signType";
            this.signType.HeaderText = "签到状态";
            this.signType.Name = "signType";
            this.signType.ReadOnly = true;
            // 
            // signData
            // 
            this.signData.DataPropertyName = "signData";
            this.signData.HeaderText = "日期";
            this.signData.Name = "signData";
            this.signData.ReadOnly = true;
            // 
            // isChecked
            // 
            this.isChecked.DataPropertyName = "isChecked";
            this.isChecked.HeaderText = "检查状态";
            this.isChecked.Name = "isChecked";
            this.isChecked.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.isChecked.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // SignForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView_sign_data);
            this.Name = "SignForm";
            this.Text = "SignForm";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_sign_data)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_sign_data;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerID;
        private System.Windows.Forms.DataGridViewTextBoxColumn signType;
        private System.Windows.Forms.DataGridViewTextBoxColumn signData;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isChecked;
    }
}