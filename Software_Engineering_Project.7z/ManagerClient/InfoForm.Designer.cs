﻿
namespace ManagerClient
{
    partial class InfoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView_worker = new System.Windows.Forms.DataGridView();
            this.workerNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerPassword = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.worderName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerSex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerBirth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerHomeAddr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerEdu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerLv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerJoinTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerBaseRec = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerAddr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerTel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button_show_workerTab = new System.Windows.Forms.Button();
            this.button_clear_infos = new System.Windows.Forms.Button();
            this.button_AddInfo = new System.Windows.Forms.Button();
            this.button_select = new System.Windows.Forms.Button();
            this.button_save_data = new System.Windows.Forms.Button();
            this.button_load_flie = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_worker)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_worker
            // 
            this.dataGridView_worker.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_worker.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.workerNumber,
            this.workerPassword,
            this.worderName,
            this.workerSex,
            this.workerBirth,
            this.workerHomeAddr,
            this.workerEdu,
            this.workerLv,
            this.workerTime,
            this.workerJoinTime,
            this.workerBaseRec,
            this.workerAddr,
            this.workerTel,
            this.Column_id});
            this.dataGridView_worker.Location = new System.Drawing.Point(228, 12);
            this.dataGridView_worker.Name = "dataGridView_worker";
            this.dataGridView_worker.RowTemplate.Height = 25;
            this.dataGridView_worker.Size = new System.Drawing.Size(560, 386);
            this.dataGridView_worker.TabIndex = 0;
            this.dataGridView_worker.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_worker_CellEndEdit);
            this.dataGridView_worker.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView_worker_ColumnHeaderMouseClick);
            // 
            // workerNumber
            // 
            this.workerNumber.DataPropertyName = "workerNumber";
            this.workerNumber.HeaderText = "账号";
            this.workerNumber.Name = "workerNumber";
            // 
            // workerPassword
            // 
            this.workerPassword.DataPropertyName = "workerPassword";
            this.workerPassword.HeaderText = "登陆密码";
            this.workerPassword.Name = "workerPassword";
            // 
            // worderName
            // 
            this.worderName.DataPropertyName = "workerName";
            this.worderName.HeaderText = "姓名";
            this.worderName.Name = "worderName";
            // 
            // workerSex
            // 
            this.workerSex.DataPropertyName = "workerSex";
            this.workerSex.HeaderText = "性别 *";
            this.workerSex.Name = "workerSex";
            this.workerSex.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // workerBirth
            // 
            this.workerBirth.DataPropertyName = "workerBirth";
            this.workerBirth.HeaderText = "出生日期 *";
            this.workerBirth.Name = "workerBirth";
            this.workerBirth.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // workerHomeAddr
            // 
            this.workerHomeAddr.DataPropertyName = "workerHomeAddr";
            this.workerHomeAddr.HeaderText = "籍贯";
            this.workerHomeAddr.Name = "workerHomeAddr";
            // 
            // workerEdu
            // 
            this.workerEdu.DataPropertyName = "workerEdu";
            this.workerEdu.HeaderText = "学历 *";
            this.workerEdu.Name = "workerEdu";
            this.workerEdu.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // workerLv
            // 
            this.workerLv.DataPropertyName = "workerLv";
            this.workerLv.HeaderText = "等级 *";
            this.workerLv.Name = "workerLv";
            this.workerLv.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // workerTime
            // 
            this.workerTime.DataPropertyName = "workerTime";
            this.workerTime.HeaderText = "工作时间 *";
            this.workerTime.Name = "workerTime";
            this.workerTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // workerJoinTime
            // 
            this.workerJoinTime.DataPropertyName = "workerJoinTime";
            this.workerJoinTime.HeaderText = "加入时间 *";
            this.workerJoinTime.Name = "workerJoinTime";
            this.workerJoinTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // workerBaseRec
            // 
            this.workerBaseRec.DataPropertyName = "workerBaseRec";
            this.workerBaseRec.HeaderText = "工资 *";
            this.workerBaseRec.Name = "workerBaseRec";
            this.workerBaseRec.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // workerAddr
            // 
            this.workerAddr.DataPropertyName = "workerAdd";
            this.workerAddr.HeaderText = "当前住址";
            this.workerAddr.Name = "workerAddr";
            // 
            // workerTel
            // 
            this.workerTel.DataPropertyName = "workerTel";
            this.workerTel.HeaderText = "电话";
            this.workerTel.Name = "workerTel";
            // 
            // Column_id
            // 
            this.Column_id.DataPropertyName = "id";
            this.Column_id.HeaderText = "id";
            this.Column_id.Name = "Column_id";
            this.Column_id.Visible = false;
            // 
            // button_show_workerTab
            // 
            this.button_show_workerTab.Location = new System.Drawing.Point(12, 30);
            this.button_show_workerTab.Name = "button_show_workerTab";
            this.button_show_workerTab.Size = new System.Drawing.Size(75, 23);
            this.button_show_workerTab.TabIndex = 1;
            this.button_show_workerTab.Text = "显示数据";
            this.button_show_workerTab.UseVisualStyleBackColor = true;
            this.button_show_workerTab.Click += new System.EventHandler(this.button_show_workerTab_Click);
            // 
            // button_clear_infos
            // 
            this.button_clear_infos.Location = new System.Drawing.Point(115, 30);
            this.button_clear_infos.Name = "button_clear_infos";
            this.button_clear_infos.Size = new System.Drawing.Size(75, 23);
            this.button_clear_infos.TabIndex = 2;
            this.button_clear_infos.Text = "清空资料";
            this.button_clear_infos.UseVisualStyleBackColor = true;
            this.button_clear_infos.Click += new System.EventHandler(this.button_clear_infos_Click);
            // 
            // button_AddInfo
            // 
            this.button_AddInfo.Location = new System.Drawing.Point(12, 78);
            this.button_AddInfo.Name = "button_AddInfo";
            this.button_AddInfo.Size = new System.Drawing.Size(75, 23);
            this.button_AddInfo.TabIndex = 3;
            this.button_AddInfo.Text = "插入记录";
            this.button_AddInfo.UseVisualStyleBackColor = true;
            this.button_AddInfo.Click += new System.EventHandler(this.button_AddInfo_Click);
            // 
            // button_select
            // 
            this.button_select.Location = new System.Drawing.Point(115, 78);
            this.button_select.Name = "button_select";
            this.button_select.Size = new System.Drawing.Size(75, 23);
            this.button_select.TabIndex = 4;
            this.button_select.Text = "查询员工";
            this.button_select.UseVisualStyleBackColor = true;
            this.button_select.Click += new System.EventHandler(this.button_select_Click);
            // 
            // button_save_data
            // 
            this.button_save_data.Location = new System.Drawing.Point(13, 124);
            this.button_save_data.Name = "button_save_data";
            this.button_save_data.Size = new System.Drawing.Size(75, 23);
            this.button_save_data.TabIndex = 5;
            this.button_save_data.Text = "保存数据";
            this.button_save_data.UseVisualStyleBackColor = true;
            this.button_save_data.Click += new System.EventHandler(this.button_save_data_Click);
            // 
            // button_load_flie
            // 
            this.button_load_flie.Location = new System.Drawing.Point(115, 124);
            this.button_load_flie.Name = "button_load_flie";
            this.button_load_flie.Size = new System.Drawing.Size(75, 23);
            this.button_load_flie.TabIndex = 6;
            this.button_load_flie.Text = "读取文件";
            this.button_load_flie.UseVisualStyleBackColor = true;
            this.button_load_flie.Click += new System.EventHandler(this.button_load_flie_Click);
            // 
            // InfoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_load_flie);
            this.Controls.Add(this.button_save_data);
            this.Controls.Add(this.button_select);
            this.Controls.Add(this.button_AddInfo);
            this.Controls.Add(this.button_clear_infos);
            this.Controls.Add(this.button_show_workerTab);
            this.Controls.Add(this.dataGridView_worker);
            this.Name = "InfoForm";
            this.Text = "InfoForm";
            this.Load += new System.EventHandler(this.InfoForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_worker)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_worker;
        private System.Windows.Forms.Button button_show_workerTab;
        private System.Windows.Forms.Button button_clear_infos;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerPassword;
        private System.Windows.Forms.DataGridViewTextBoxColumn worderName;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerSex;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerBirth;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerHomeAddr;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerEdu;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerLv;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerJoinTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerBaseRec;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerAddr;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerTel;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column_id;
        private System.Windows.Forms.Button button_AddInfo;
        private System.Windows.Forms.Button button_select;
        private System.Windows.Forms.Button button_save_data;
        private System.Windows.Forms.Button button_load_flie;
    }
}